# Docker Machine 项目

![](https://docs.docker.com/machine/img/machine.png)

Docker Machine 是 Docker 官方编排（Orchestration）项目之一，负责在多种平台上快速安装 Docker 环境。

Docker Machine 项目基于 Go 语言实现，目前在 [Github](https://github.com/docker/machine) 上进行维护。

本章将介绍 Docker Machine 的安装及使用。
