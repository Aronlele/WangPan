# Docker 开源项目

本章介绍 Docker 开源的项目。随着 Docker 功能的越来越多，Docker 也加快了开源的步伐，Docker 未来会将引擎拆分为更多开放组件，对用于组装 Docker 产品的各种新型工具与组件进行开源并供技术社区使用。
