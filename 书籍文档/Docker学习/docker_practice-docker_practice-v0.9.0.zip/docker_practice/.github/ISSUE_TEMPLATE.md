* [ ] Have u googled the problem? If no, pls do that first!

### Environment
<!--请提供环境信息，包括操作系统版本等-->
<!--Provides env info like OS version-->

* [x] Linux
   * [x] CentOS 7
   * [ ] Ubuntu 16.04
   * [ ] Ubuntu 17.10
   * [ ] Debian 9
   * [ ] Debian 8
   * [ ] CoreOS
* [ ] macOS
* [ ] Windows 10
* [ ] Raspberry Pi (ARM)
* [ ] Others (Pls describe below)

### Docker Version
<!--如果你的 Docker 版本低于 17.09 请尽可能升级到该版本-->
<!--if Docker version under 17.09, please upgrade Docker to 17.09-->

* [x] 17.11 Edge
* [ ] 17.09 Stable
* [ ] 1.13.0 or Before

### Problem Description
<!--描述你的问题，请贴出操作步骤，终端报错日志-->
<!--describe problem with detailed steps and logs-->
